<?php

//sql db connection
$servername = "localhost";
$username = "root";
$password = "";
$dbase = "db_project";

$conn = new mysqli($servername, $username, $password, $dbase);

?>